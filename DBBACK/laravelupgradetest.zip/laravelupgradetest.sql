-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 18, 2024 at 12:10 PM
-- Server version: 8.3.0
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravelupgradetest`
--

-- --------------------------------------------------------

--
-- Table structure for table `chapters`
--

DROP TABLE IF EXISTS `chapters`;
CREATE TABLE IF NOT EXISTS `chapters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `truedialog_participantchapterlist_id` int DEFAULT NULL,
  `truedialog_leaderchapterlist_id` int DEFAULT NULL,
  `chapter_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `chapter_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Other',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=644 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chapters`
--

INSERT INTO `chapters` (`id`, `truedialog_participantchapterlist_id`, `truedialog_leaderchapterlist_id`, `chapter_name`, `chapter_type`, `created_at`, `updated_at`) VALUES
(338, NULL, NULL, '* NO CHAPTERS WITHIN REACH', 'Other', NULL, NULL),
(339, NULL, NULL, 'AL - Anniston', 'Other', NULL, NULL),
(340, NULL, NULL, 'AL - Mobile', 'Other', NULL, NULL),
(341, NULL, NULL, 'AL - Montgomery', 'Other', NULL, NULL),
(342, NULL, NULL, 'AR - Central Arkansas', 'Other', NULL, NULL),
(343, NULL, NULL, 'AR - Rogers', 'Other', NULL, NULL),
(344, NULL, NULL, 'AZ - Gilbert', 'Other', NULL, NULL),
(345, NULL, NULL, 'CA - Long Beach', 'Other', NULL, NULL),
(346, NULL, NULL, 'CA - Long Beach Holy Innocents School', 'Schools', NULL, NULL),
(347, NULL, NULL, 'CA - Napa', 'Other', NULL, NULL),
(348, NULL, NULL, 'CA - Reedley', 'Other', NULL, NULL),
(349, NULL, NULL, 'CA - Sacramento', 'Other', NULL, NULL),
(350, NULL, NULL, 'CA - San Diego', 'Other', NULL, NULL),
(351, NULL, NULL, 'CA - San Francisco', 'Other', NULL, NULL),
(352, NULL, NULL, 'CO - Boulder County', 'Other', NULL, NULL),
(353, NULL, NULL, 'CO - Colorado Springs', 'Other', NULL, NULL),
(354, NULL, NULL, 'CO - Denver', 'Other', NULL, NULL),
(355, NULL, NULL, 'CO - Pueblo', 'Other', NULL, NULL),
(356, NULL, NULL, 'CT - Holy Apostles College & Seminary', 'Colleges', NULL, NULL),
(357, NULL, NULL, 'CT - Stamford', 'Other', NULL, NULL),
(358, NULL, NULL, 'DC - Beltway', 'Other', NULL, NULL),
(359, NULL, NULL, 'DE - Wilmington', 'Other', NULL, NULL),
(360, NULL, NULL, 'Eritrea', 'International', NULL, NULL),
(361, NULL, NULL, 'Fiji', 'International', NULL, NULL),
(362, NULL, NULL, 'Fiji - Lautoka', 'International', NULL, NULL),
(363, NULL, NULL, 'Fiji - Nadi', 'International', NULL, NULL),
(364, NULL, NULL, 'Fiji - Suva', 'International', NULL, NULL),
(365, NULL, NULL, 'FL - Ave Maria Univ', 'Colleges', NULL, NULL),
(366, NULL, NULL, 'FL - Ave Maria (town)', 'Other', NULL, NULL),
(367, NULL, NULL, 'FL - Ave Maria School of Law', 'Colleges', NULL, NULL),
(368, NULL, NULL, 'FL - Crestview', 'Other', NULL, NULL),
(369, NULL, NULL, 'FL - Fort Walton Beach St Mary\'s School', 'Schools', NULL, NULL),
(370, NULL, NULL, 'FL - Niceville', 'Other', NULL, NULL),
(371, NULL, NULL, 'FL - Palm Beach', 'Other', NULL, NULL),
(372, NULL, NULL, 'FL - Parrish', 'Other', NULL, NULL),
(373, NULL, NULL, 'FL - Pensacola', 'Other', NULL, NULL),
(374, NULL, NULL, 'FL - Pensacola St Paul Catholic School', 'Schools', NULL, NULL),
(375, NULL, NULL, 'GA - Acworth', 'Other', NULL, NULL),
(376, NULL, NULL, 'GA - Evans', 'Other', NULL, NULL),
(377, NULL, NULL, 'HI - Oahu', 'Other', NULL, NULL),
(378, NULL, NULL, 'IA - Des Moines', 'Other', NULL, NULL),
(379, NULL, NULL, 'IA - Sioux City', 'Other', NULL, NULL),
(380, NULL, NULL, 'IA - Sioux City Heelan HS', 'Schools', NULL, NULL),
(381, NULL, NULL, 'IA - Sioux City Mater Dei Catholic School', 'Schools', NULL, NULL),
(382, NULL, NULL, 'IA - Sioux City Sacred Heart School', 'Schools', NULL, NULL),
(383, NULL, NULL, 'ID - Boise', 'Other', NULL, NULL),
(384, NULL, NULL, 'IL - Chicago', 'Other', NULL, NULL),
(385, NULL, NULL, 'IL - Dunlap', 'Other', NULL, NULL),
(386, NULL, NULL, 'IL - Effingham', 'Other', NULL, NULL),
(387, NULL, NULL, 'IL - Springfield', 'Other', NULL, NULL),
(388, NULL, NULL, 'IN - Indianapolis', 'Other', NULL, NULL),
(389, NULL, NULL, 'India - Pune', 'International', NULL, NULL),
(390, NULL, NULL, 'Kenya', 'International', NULL, NULL),
(391, NULL, NULL, 'KS - Beloit', 'Other', NULL, NULL),
(392, NULL, NULL, 'KS - Beloit St John Schools', 'Schools', NULL, NULL),
(393, NULL, NULL, 'KS - Benedictine College', 'Colleges', NULL, NULL),
(394, NULL, NULL, 'KS - Garnett St Rose School', 'Schools', NULL, NULL),
(395, NULL, NULL, 'KS - Greeley', 'Other', NULL, NULL),
(396, NULL, NULL, 'KS - Olathe', 'Other', NULL, NULL),
(397, NULL, NULL, 'KS - Overland Park', 'Other', NULL, NULL),
(398, NULL, NULL, 'KS - Overland Park Church of the Ascension', 'Other', NULL, NULL),
(399, NULL, NULL, 'KS - Topeka', 'Other', NULL, NULL),
(400, NULL, NULL, 'KS - Wichita', 'Other', NULL, NULL),
(401, NULL, NULL, 'LA - Baton Rouge', 'Other', NULL, NULL),
(402, NULL, NULL, 'LA - Lafayette', 'Other', NULL, NULL),
(403, NULL, NULL, 'LA - New Orleans', 'Other', NULL, NULL),
(404, NULL, NULL, 'Liberia', 'International', NULL, NULL),
(405, NULL, NULL, 'MA - Scituate', 'Other', NULL, NULL),
(406, NULL, NULL, 'MA - Springfield', 'Other', NULL, NULL),
(407, NULL, NULL, 'MA - Still River', 'Schools', NULL, NULL),
(408, NULL, NULL, 'MD - Baltimore', 'Other', NULL, NULL),
(409, NULL, NULL, 'MD - Calvert County', 'Other', NULL, NULL),
(410, NULL, NULL, 'MD - St. Mary\'s Hagerstown', 'Other', NULL, NULL),
(411, NULL, NULL, 'MEX - Autlan', 'International', NULL, NULL),
(412, NULL, NULL, 'MEX - Cuautitlan Izcalli', 'International', NULL, NULL),
(413, NULL, NULL, 'MEX - Monterrey', 'International', NULL, NULL),
(414, NULL, NULL, 'MI - Detroit', 'Other', NULL, NULL),
(415, NULL, NULL, 'MI - Everest Catholic School', 'Schools', NULL, NULL),
(416, NULL, NULL, 'MI - Gaylord', 'Other', NULL, NULL),
(417, NULL, NULL, 'MI - Gaylord St. Mary Cathedral School', 'Schools', NULL, NULL),
(418, NULL, NULL, 'MI - Lansing', 'Other', NULL, NULL),
(419, NULL, NULL, 'MI - Traverse City', 'Other', NULL, NULL),
(420, NULL, NULL, 'MO - Cape Girardeau', 'Other', NULL, NULL),
(421, NULL, NULL, 'MO - Chillicothe', 'Other', NULL, NULL),
(422, NULL, NULL, 'MO - Helias CHS', 'Schools', NULL, NULL),
(423, NULL, NULL, 'MO - Jefferson City', 'Other', NULL, NULL),
(424, NULL, NULL, 'MO - Jefferson City Blair Oaks HS', 'Schools', NULL, NULL),
(425, NULL, NULL, 'MO - Jefferson City High School', 'Schools', NULL, NULL),
(426, NULL, NULL, 'MO - Jefferson City Immaculate Conception School', 'Schools', NULL, NULL),
(427, NULL, NULL, 'MO - Jefferson City St Joseph Cathedral School', 'Schools', NULL, NULL),
(428, NULL, NULL, 'MO - Jefferson City St Peter School', 'Schools', NULL, NULL),
(429, NULL, NULL, 'MO - Jefferson City St Stanislaus School', 'Schools', NULL, NULL),
(430, NULL, NULL, 'MO - Kansas City', 'Other', NULL, NULL),
(431, NULL, NULL, 'MO - Kenrick-Glennon Seminary', 'Colleges', NULL, NULL),
(432, NULL, NULL, 'MO - Springfield', 'Other', NULL, NULL),
(433, NULL, NULL, 'MO - St. Louis', 'Other', NULL, NULL),
(434, NULL, NULL, 'MO - St. Louis - JohnPaul2', 'Schools', NULL, NULL),
(435, NULL, NULL, 'MO - St. Louis St Francis of Assisi School', 'Schools', NULL, NULL),
(436, NULL, NULL, 'MO - St. Louis St. Austin School', 'Schools', NULL, NULL),
(437, NULL, NULL, 'MO - St. Martin School', 'Schools', NULL, NULL),
(438, NULL, NULL, 'MO - Taos St Francis Xavier School', 'Schools', NULL, NULL),
(439, NULL, NULL, 'MO - Thomas Jefferson Middle School', 'Schools', NULL, NULL),
(440, NULL, NULL, 'MO - Warrensburg', 'Other', NULL, NULL),
(441, NULL, NULL, 'MO - Wentzville', 'Other', NULL, NULL),
(442, NULL, NULL, 'MO - Westphalia St Joseph School', 'Schools', NULL, NULL),
(443, NULL, NULL, 'MS - Biloxi', 'Other', NULL, NULL),
(444, NULL, NULL, 'MS - Diamondhead', 'Other', NULL, NULL),
(445, NULL, NULL, 'NC - Jacksonville', 'Other', NULL, NULL),
(446, NULL, NULL, 'NC - Rocky Mount', 'Other', NULL, NULL),
(447, NULL, NULL, 'ND - Grand Forks', 'Other', NULL, NULL),
(448, NULL, NULL, 'ND - Killdeer', 'Other', NULL, NULL),
(449, NULL, NULL, 'NE - Auburn', 'Other', NULL, NULL),
(450, NULL, NULL, 'NE - Bellevue Gross Catholic HS', 'Schools', NULL, NULL),
(451, NULL, NULL, 'NE - Bellevue St Mary Catholic Church', 'Other', NULL, NULL),
(452, NULL, NULL, 'NE - Bellevue St Matthew Catholic Church', 'Other', NULL, NULL),
(453, NULL, NULL, 'NE - Bellevue St Matthew Catholic School', 'Schools', NULL, NULL),
(454, NULL, NULL, 'NE - Creighton (town)', 'Other', NULL, NULL),
(455, NULL, NULL, 'NE - Creighton Prep HS', 'Schools', NULL, NULL),
(456, NULL, NULL, 'NE - Creighton University', 'Colleges', NULL, NULL),
(457, NULL, NULL, 'NE - Omaha Immaculate Conception', 'Other', NULL, NULL),
(458, NULL, NULL, 'NE - Lincoln', 'Other', NULL, NULL),
(459, NULL, NULL, 'NE - Omaha', 'Other', NULL, NULL),
(460, NULL, NULL, 'NE - Omaha Central HS', 'Other', NULL, NULL),
(461, NULL, NULL, 'NE - Omaha Skutt Catholic HS', 'Schools', NULL, NULL),
(462, NULL, NULL, 'NE - Omaha St James Seton School', 'Schools', NULL, NULL),
(463, NULL, NULL, 'NE - Omaha St Peter and Paul Catholic ES', 'Schools', NULL, NULL),
(464, NULL, NULL, 'NE - Omaha Chesterton Academy', 'Schools', NULL, NULL),
(465, NULL, NULL, 'NE - Papillion St Columbkille School', 'Schools', NULL, NULL),
(466, NULL, NULL, 'NE - Papio South HS', 'Other', NULL, NULL),
(467, NULL, NULL, 'NE - Plattsmouth', 'Other', NULL, NULL),
(468, NULL, NULL, 'NE - Plattsmouth St John the Baptist School', 'Schools', NULL, NULL),
(469, NULL, NULL, 'NE - Ralston St. Gerald School', 'Schools', NULL, NULL),
(470, NULL, NULL, 'NE - South Sioux City St. Michael\'s Catholic School/MHCC', 'Schools', NULL, NULL),
(471, NULL, NULL, 'NE - West Point', 'Other', NULL, NULL),
(472, NULL, NULL, 'NE - West Point Guardian Angels School', 'Schools', NULL, NULL),
(473, NULL, NULL, 'NE - West Point St Paul Lutheran School', 'Schools', NULL, NULL),
(474, NULL, NULL, 'New Zealand - Christchurch', 'International', NULL, NULL),
(475, NULL, NULL, 'NH - Danbury', 'Other', NULL, NULL),
(476, NULL, NULL, 'NJ - Deptford', 'Other', NULL, NULL),
(477, NULL, NULL, 'NJ - St. Cecilia', 'Other', NULL, NULL),
(478, NULL, NULL, 'NM - Albuquerque', 'Other', NULL, NULL),
(479, NULL, NULL, 'NM - Aztec', 'Other', NULL, NULL),
(480, NULL, NULL, 'NY - Albany', 'Other', NULL, NULL),
(481, NULL, NULL, 'NY - Finger Lakes', 'Other', NULL, NULL),
(482, NULL, NULL, 'NY - Long Island', 'Other', NULL, NULL),
(483, NULL, NULL, 'NY - New York City', 'Other', NULL, NULL),
(484, NULL, NULL, 'OH - Chardon', 'Other', NULL, NULL),
(485, NULL, NULL, 'OH - Cincinnati', 'Other', NULL, NULL),
(486, NULL, NULL, 'OH - Crown City', 'Other', NULL, NULL),
(487, NULL, NULL, 'OH - Dayton', 'Other', NULL, NULL),
(488, NULL, NULL, 'OH - Franciscan Univ', 'Colleges', NULL, NULL),
(489, NULL, NULL, 'OH - Toledo-NW', 'Other', NULL, NULL),
(490, NULL, NULL, 'OR - Hillsboro', 'Other', NULL, NULL),
(491, NULL, NULL, 'PA - Nazareth', 'Other', NULL, NULL),
(492, NULL, NULL, 'PA - Philadelphia', 'Other', NULL, NULL),
(493, NULL, NULL, 'PA - Pittsburgh', 'Other', NULL, NULL),
(494, NULL, NULL, 'Poland', 'International', NULL, NULL),
(495, NULL, NULL, 'SC - Aiken', 'Other', NULL, NULL),
(496, NULL, NULL, 'SD - Aberdeen', 'Other', NULL, NULL),
(497, NULL, NULL, 'SD - Elk Point Jefferson School', 'Schools', NULL, NULL),
(498, NULL, NULL, 'SD - Elkton/Lake Benton', 'Other', NULL, NULL),
(499, NULL, NULL, 'SD - Rapid City', 'Other', NULL, NULL),
(500, NULL, NULL, 'SD - SDSU', 'Other', NULL, NULL),
(501, NULL, NULL, 'SD - Sioux Falls', 'Other', NULL, NULL),
(502, NULL, NULL, 'SD - Sioux Falls (Augustana Univ)', 'Colleges', NULL, NULL),
(503, NULL, NULL, 'SD - Sioux Falls St. Katharine Drexel School', 'Schools', NULL, NULL),
(504, NULL, NULL, 'SD - St Thomas More HS', 'Schools', NULL, NULL),
(505, NULL, NULL, 'SD - Watertown', 'Other', NULL, NULL),
(506, NULL, NULL, 'SD - Yankton', 'Other', NULL, NULL),
(507, NULL, NULL, 'Sierra Leone', 'International', NULL, NULL),
(508, NULL, NULL, 'Singapore', 'International', NULL, NULL),
(509, NULL, NULL, 'Tanzania - Tabora', 'International', NULL, NULL),
(510, NULL, NULL, 'Tonga', 'International', NULL, NULL),
(511, NULL, NULL, 'TX - Austin', 'Other', NULL, NULL),
(512, NULL, NULL, 'TX - Corpus Christi', 'Other', NULL, NULL),
(513, NULL, NULL, 'TX - Dallas/Fort Worth', 'Other', NULL, NULL),
(514, NULL, NULL, 'TX - Houston', 'Other', NULL, NULL),
(515, NULL, NULL, 'TX - Odessa', 'Other', NULL, NULL),
(516, NULL, NULL, 'TX - San Antonio', 'Other', NULL, NULL),
(517, NULL, NULL, 'TX - Taft-Portland', 'Other', NULL, NULL),
(518, NULL, NULL, 'Uganda - Jinja', 'International', NULL, NULL),
(519, NULL, NULL, 'VA - Fredericksburg', 'Other', NULL, NULL),
(520, NULL, NULL, 'VA - Fredericksburg St Mary Youth Ministry', 'Schools', NULL, NULL),
(521, NULL, NULL, 'VA - Leesburg', 'Other', NULL, NULL),
(522, NULL, NULL, 'VA - Manassas', 'Other', NULL, NULL),
(523, NULL, NULL, 'Vanuatu', 'International', NULL, NULL),
(524, NULL, NULL, 'WA - Western Washington', 'Other', NULL, NULL),
(525, NULL, NULL, 'WI - Eau Claire', 'Other', NULL, NULL),
(526, NULL, NULL, 'WI - Milwaukee', 'Other', NULL, NULL),
(527, NULL, NULL, 'MO - Bloomsdale St. Agnes', 'Other', NULL, NULL),
(528, NULL, NULL, 'SC - Columbia', 'Other', NULL, NULL),
(529, NULL, NULL, 'SD - Sioux Falls Christ the King School', 'Schools', NULL, NULL),
(530, NULL, NULL, 'OK - Broken Arrow', 'Other', NULL, NULL),
(531, NULL, NULL, 'DC - Catholic Univ of America', 'Colleges', NULL, NULL),
(532, NULL, NULL, 'NE - Omaha St Cecilia School', 'Schools', NULL, NULL),
(533, NULL, NULL, 'NE - Omaha St Cecilia Church', 'Other', NULL, NULL),
(534, NULL, NULL, 'NE - UNO', 'Colleges', NULL, NULL),
(535, NULL, NULL, 'MN - Duluth', 'Other', NULL, NULL),
(536, NULL, NULL, 'KS - Manhattan', 'Other', NULL, NULL),
(537, NULL, NULL, 'IL - Glen Carbon', 'Other', NULL, NULL),
(538, NULL, NULL, 'SD - Pierre', 'Other', NULL, NULL),
(539, NULL, NULL, 'MO - Columbia MIZZOU', 'Colleges', NULL, NULL),
(540, NULL, NULL, 'TN - Knoxville', 'Other', NULL, NULL),
(541, NULL, NULL, 'OH - Hudson', 'Other', NULL, NULL),
(542, NULL, NULL, 'SD - Ipswich', 'Other', NULL, NULL),
(543, NULL, NULL, 'NC - Triangle Area', 'Other', NULL, NULL),
(544, NULL, NULL, 'MO - St. Thomas School', 'Schools', NULL, NULL),
(545, NULL, NULL, 'ND - Bismarck Mandan', 'Other', NULL, NULL),
(546, NULL, NULL, 'Executive', 'Other', NULL, NULL),
(547, NULL, NULL, 'MN - Twin Cities', 'Other', NULL, NULL),
(548, NULL, NULL, 'PatTest', 'Other', NULL, NULL),
(549, NULL, NULL, 'NE - Hastings', 'Other', NULL, NULL),
(550, NULL, NULL, 'IA - Council Bluffs', 'Other', NULL, NULL),
(551, NULL, NULL, 'SD - USD', 'Colleges', NULL, NULL),
(552, NULL, NULL, 'Elite Athletes', 'Other', NULL, NULL),
(553, NULL, NULL, 'NE - Fremont', 'Other', NULL, NULL),
(554, NULL, NULL, 'MO - St. Louis St. Mary\'s HS', 'Schools', NULL, NULL),
(555, NULL, NULL, 'NE - Papio LV HS', 'Other', NULL, NULL),
(556, NULL, NULL, 'WY - Gillette', 'Other', NULL, NULL),
(557, NULL, NULL, 'NE - Omaha Christendom Academy', 'Schools', NULL, NULL),
(558, NULL, NULL, 'NE - Bellevue West HS', 'Other', NULL, NULL),
(559, NULL, NULL, 'NE - Ralston St. Gerald Church', 'Other', NULL, NULL),
(560, NULL, NULL, 'NE - Nebraska City Lourdes School', 'Schools', NULL, NULL),
(561, NULL, NULL, 'MD - Prince George\'s County', 'Other', NULL, NULL),
(562, NULL, NULL, 'PA - Reading', 'Other', NULL, NULL),
(563, NULL, NULL, 'SD - Vermillion', 'Other', NULL, NULL),
(564, NULL, NULL, 'NC - Swannanoa St Margaret Mary', 'Other', NULL, NULL),
(565, NULL, NULL, 'Nigeria - Enugu', 'International', NULL, NULL),
(566, NULL, NULL, 'MN - Pierz 1Cor9:26', 'Other', NULL, NULL),
(567, NULL, NULL, 'MO - St Elizabeth School', 'Schools', NULL, NULL),
(568, NULL, NULL, 'Nigeria - Sokoto', 'International', NULL, NULL),
(569, NULL, NULL, 'TX - El Paso', 'Other', NULL, NULL),
(570, NULL, NULL, 'SD - Yankton Sacred Heart School', 'Schools', NULL, NULL),
(571, NULL, NULL, 'UT - Riverton St. Andrews Catholic Church', 'Other', NULL, NULL),
(572, NULL, NULL, 'VA - Great Falls/NOVA', 'Other', NULL, NULL),
(573, NULL, NULL, 'Nigeria - Lokoja University', 'International', NULL, NULL),
(574, NULL, NULL, 'NE - Omaha St Philip Neri School', 'Schools', NULL, NULL),
(575, NULL, NULL, 'NE - Omaha Mercy HS', 'Schools', NULL, NULL),
(576, NULL, NULL, 'Uganda - Kabale', 'International', NULL, NULL),
(577, NULL, NULL, 'MO - St Joseph', 'Other', NULL, NULL),
(578, NULL, NULL, 'CA - Wrightwood', 'Other', NULL, NULL),
(579, NULL, NULL, 'NE - UNL', 'Colleges', NULL, NULL),
(580, NULL, NULL, 'NE - Bellevue St Bernadette School', 'Schools', NULL, NULL),
(581, NULL, NULL, 'NE - Humphrey St Francis School', 'Schools', NULL, NULL),
(582, NULL, NULL, 'NE - Humphrey', 'Other', NULL, NULL),
(583, NULL, NULL, 'NE - Lindsay', 'Other', NULL, NULL),
(584, NULL, NULL, 'NE - Lindsay Holy Family School', 'Schools', NULL, NULL),
(585, NULL, NULL, 'NC - Triangle Youth', 'Schools', NULL, NULL),
(586, NULL, NULL, 'NC - Huntersville', 'Other', NULL, NULL),
(587, NULL, NULL, 'TX - Abilene', 'Other', NULL, NULL),
(588, NULL, NULL, 'TN - Brentwood', 'Other', NULL, NULL),
(589, NULL, NULL, 'WY - Casper', 'Other', NULL, NULL),
(590, NULL, NULL, 'MI - Kalamazoo St Monica ES', 'Schools', NULL, NULL),
(591, NULL, NULL, 'MI - Kalamazoo', 'Other', NULL, NULL),
(592, NULL, NULL, 'NE - Omaha St Robert School', 'Schools', NULL, NULL),
(593, NULL, NULL, 'NE - Omaha St Robert Church', 'Other', NULL, NULL),
(594, NULL, NULL, 'MA - Worcester Polytechnic Institute', 'Colleges', NULL, NULL),
(595, NULL, NULL, 'MO - Jefferson City Calvary HS', 'Schools', NULL, NULL),
(596, NULL, NULL, 'Pakistan - Lahore', 'International', NULL, NULL),
(597, NULL, NULL, 'LA - Shreveport', 'Other', NULL, NULL),
(598, NULL, NULL, 'OH - Lakewood Pio Academy', 'Schools', NULL, NULL),
(599, NULL, NULL, 'NE - Omaha St Bernard School', 'Schools', NULL, NULL),
(600, NULL, NULL, 'RI - Providence', 'Other', NULL, NULL),
(601, NULL, NULL, 'VA - Newport News Peninsula HS', 'Schools', NULL, NULL),
(602, NULL, NULL, 'GA - Monroe', 'Other', NULL, NULL),
(603, NULL, NULL, 'Uganda - Rubanda', 'International', NULL, NULL),
(604, NULL, NULL, 'TN - Memphis', 'Other', NULL, NULL),
(605, NULL, NULL, 'SC - Aiken St Mary School', 'Schools', NULL, NULL),
(606, NULL, NULL, 'NM - Gallup', 'Other', NULL, NULL),
(607, NULL, NULL, 'NE - Lincoln St Peter School', 'Schools', NULL, NULL),
(608, NULL, NULL, 'SC - Charleston', 'Other', NULL, NULL),
(609, NULL, NULL, 'NC - Polk County', 'Other', NULL, NULL),
(610, NULL, NULL, 'Germany', 'International', NULL, NULL),
(611, NULL, NULL, 'NE - Denton OLG Seminary', 'Other', NULL, NULL),
(612, NULL, NULL, 'AL - Birmingham', 'Other', NULL, NULL),
(613, NULL, NULL, 'PA - St Charles Borromeo Seminary', 'Colleges', NULL, NULL),
(614, NULL, NULL, 'TX - Univ of Dallas', 'Colleges', NULL, NULL),
(615, NULL, NULL, 'NE - Wayne State College', 'Colleges', NULL, NULL),
(616, NULL, NULL, 'KS - Salina', 'Other', NULL, NULL),
(617, NULL, NULL, 'KS - Junction City', 'Other', NULL, NULL),
(618, NULL, NULL, 'KS - Hays', 'Other', NULL, NULL),
(619, NULL, NULL, 'KS - Tipton', 'Other', NULL, NULL),
(620, NULL, NULL, 'MO - Cape Girardeau Notre Dame HS', 'Schools', NULL, NULL),
(621, NULL, NULL, 'TX - Pipe Creek Lumen Christi Academy', 'Schools', NULL, NULL),
(622, NULL, NULL, 'NE - Seward St Vincent de Paul ES', 'Schools', NULL, NULL),
(623, NULL, NULL, 'OK - Midwest City', 'Other', NULL, NULL),
(624, NULL, NULL, 'CO - Monument St Peter School', 'Schools', NULL, NULL),
(625, NULL, NULL, 'MN - Rochester', 'Other', NULL, NULL),
(626, NULL, NULL, 'Rwanda', 'International', NULL, NULL),
(640, NULL, NULL, 'New Chapter 1', 'Other', '2024-09-18 04:17:39', '2024-09-18 04:17:39'),
(641, NULL, NULL, 'New Chapter 2', 'Other', '2024-09-18 04:17:39', '2024-09-18 04:17:39'),
(642, NULL, NULL, 'New Chapter 3', 'Other', '2024-09-18 04:17:39', '2024-09-18 04:17:39'),
(643, NULL, NULL, 'New Chapter 4', 'Other', '2024-09-18 04:17:39', '2024-09-18 04:17:39');

-- --------------------------------------------------------

--
-- Table structure for table `dummies`
--

DROP TABLE IF EXISTS `dummies`;
CREATE TABLE IF NOT EXISTS `dummies` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dummies`
--

INSERT INTO `dummies` (`id`, `name`, `email`, `created_at`, `updated_at`) VALUES
(11, 'test', 'test@gmail.com', '2024-09-18 04:18:21', '2024-09-18 04:18:21'),
(12, 'test1', 'test1@gmail.com', '2024-09-18 04:18:21', '2024-09-18 04:18:21');

-- --------------------------------------------------------

--
-- Table structure for table `email_log`
--

DROP TABLE IF EXISTS `email_log`;
CREATE TABLE IF NOT EXISTS `email_log` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `from` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bcc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `headers` text COLLATE utf8mb4_unicode_ci,
  `attachments` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leadertochapters`
--

DROP TABLE IF EXISTS `leadertochapters`;
CREATE TABLE IF NOT EXISTS `leadertochapters` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `chapter_id` int NOT NULL,
  `leader_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(3, '2015_07_31_1_email_log', 2),
(4, '2016_09_21_001638_add_bcc_column_email_log', 2),
(5, '2017_11_10_001638_add_more_mail_columns_email_log', 2),
(6, '2016_06_01_000001_create_oauth_auth_codes_table', 3),
(7, '2016_06_01_000002_create_oauth_access_tokens_table', 3),
(8, '2016_06_01_000003_create_oauth_refresh_tokens_table', 3),
(9, '2016_06_01_000004_create_oauth_clients_table', 3),
(10, '2016_06_01_000005_create_oauth_personal_access_clients_table', 3),
(11, '2014_10_12_000000_create_users_table', 4),
(12, '2014_10_12_100000_create_password_resets_table', 4),
(13, '2018_10_08_054345_create_chapters_table', 5),
(14, '2018_10_08_094327_create_roles_table', 5),
(15, '2018_10_10_082108_create_leadertochapters_table', 5),
(16, '2018_10_15_060918_create_participanttochapters_table', 5),
(17, '2018_10_15_055351_add_country_to_users', 6),
(18, '2018_10_16_071557_alter_table_user_phone', 7),
(19, '2019_09_12_033808_alter_table_users_add_field_optin', 8),
(20, '2019_09_12_060619_alter_table_users_add_nullabe_to_phone_number_field', 8),
(21, '2019_09_19_052444_alter_table_users_add_nullable_to_birthdate_field', 8),
(22, '2019_10_29_034740_alter_table_users_add_field_email_optin', 9),
(23, '2021_05_20_030327_alter_table_chapters_add_new_field_chapter_type', 10),
(24, '2024_09_18_045514_create_dummy_table', 11);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int DEFAULT NULL,
  `client_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('00ff878ece6895d2a05a45e014ca67de6e7dfe5271eabe570fa422cbd31bad29256e7bac56864216', 1, 1, NULL, '[]', 0, '2024-09-18 00:41:45', '2024-09-18 00:41:45', '2025-09-18 06:11:45'),
('05c566f2ce75e10ec16be13e7c4b358cada1af1886850bcc0ba78928af31921ee5975003a5b4e8ab', 1, 1, NULL, '[]', 0, '2024-09-18 00:44:50', '2024-09-18 00:44:50', '2025-09-18 06:14:50'),
('07f0e3cb0d6abf0a60ba565df6d49752c60a2398d8928f7ad3870c4b60a4677110bfd7ddb9cb40aa', 1, 1, NULL, '[]', 0, '2024-09-18 00:42:33', '2024-09-18 00:42:33', '2025-09-18 06:12:33'),
('0f5b3ed1d6c4322a1104b3588b373f511f716470f67251cdaa4e77942eff11c0cfb471a51770fbeb', 1, 1, NULL, '[]', 0, '2024-09-18 01:32:23', '2024-09-18 01:32:23', '2025-09-18 07:02:23'),
('1140bbc297e067fcb47e62775a43590f4986e8c6a85f8696f508b72c799241f2ea3f99b543399031', 21, 1, 'LiferunnerApp', '[]', 0, '2024-09-17 05:56:43', '2024-09-17 05:56:43', '2025-09-17 11:26:43'),
('13ce34226321ac34320e7c3f4f0e93d4691a8fb6fe11dac136eddd7eac61ca5d5fae41393405e01e', 1, 1, NULL, '[]', 0, '2024-09-18 00:56:47', '2024-09-18 00:56:47', '2025-09-18 06:26:47'),
('14e4d1c08f489b14d56a944a109a5bdba86e00147e66a27f3a2f3d926dc2db130271e9206907e3cc', 1, 3, NULL, '[]', 0, '2024-09-18 03:44:18', '2024-09-18 03:44:18', '2025-09-18 09:14:18'),
('16e5fabac9e7761409dd654704de2ff5c982f677fd11487490d5ff5d613b55e347cbf2dd0501ebe9', 21, 1, NULL, '[]', 0, '2024-09-17 05:51:49', '2024-09-17 05:51:49', '2025-09-17 11:21:49'),
('1830a833811650f4a22c75303bc710e9230aa08af4564c2f8a62aef60156f9321c71dd038c592ac4', 1, 1, NULL, '[]', 0, '2024-09-18 00:41:29', '2024-09-18 00:41:29', '2025-09-18 06:11:29'),
('200aaee5549852b0a8ac19520eb3f2ca6aa49f98bda4175bc39b565576411a00764cfe98ded98c28', 21, 1, NULL, '[]', 0, '2024-09-17 05:55:22', '2024-09-17 05:55:22', '2025-09-17 11:25:22'),
('20b18f32cf876b0ffb783545ed051b9047601df435327b0bcbd9dfc959ea347adde44ebc68188781', 21, 1, NULL, '[]', 0, '2024-09-17 05:55:45', '2024-09-17 05:55:45', '2025-09-17 11:25:45'),
('26bab5ec3beee884e611b7fb7231470c1da8c8faf9e7ea6775dafd535f7ffb264ec866063a4b71e7', 1, 1, NULL, '[]', 0, '2024-09-18 02:19:59', '2024-09-18 02:19:59', '2025-09-18 07:49:59'),
('287e7eeb23a789c1c1cdaeaae7be87c05b4f8e49c1f0b79d8d2ab54d3ca21f3b74488ef3f1221ea7', 1, 1, NULL, '[]', 0, '2024-09-18 00:45:31', '2024-09-18 00:45:31', '2025-09-18 06:15:31'),
('2f836f03f1b2fd6cbb9ba3287b005d0ae50a41aa3a4f83430d93cf5ea977c9e3b4c6ad402f7736f5', 1, 3, NULL, '[]', 0, '2024-09-18 03:44:40', '2024-09-18 03:44:40', '2025-09-18 09:14:40'),
('316415e278d0dc5d381d06b1690e97369e64a75a6dca2f5d87c7ffbe32db4ba554f437fba659c9d6', 1, 3, NULL, '[]', 0, '2024-09-18 03:44:38', '2024-09-18 03:44:38', '2025-09-18 09:14:38'),
('32724fc8b8dd58c7ffa72bbdf88f7f7b8c98da424da68f8d6aa888aad9b94cbf70fb2a750db04c2e', 1, 3, NULL, '[]', 0, '2024-09-18 03:46:38', '2024-09-18 03:46:38', '2025-09-18 09:16:38'),
('3a12de7d458b807c611e62d421bf3f0afbf925174116cdf1618d26c93b984f2511ba33514636e9c6', 1, 1, NULL, '[]', 0, '2024-09-18 00:59:36', '2024-09-18 00:59:36', '2025-09-18 06:29:36'),
('3b7bc134ec47532b2581ab69fcadeb5d052c96e3d516e3745f67ed9c4b4f05e6c6ad0e67a28e5fec', 1, 1, NULL, '[]', 0, '2024-09-18 00:46:50', '2024-09-18 00:46:50', '2025-09-18 06:16:50'),
('3d4a6681d659e039df5b57d9bcae837ebba3abbf3c39d949cdb01603311fce30d699618be34bd357', 21, 1, NULL, '[]', 0, '2024-09-17 05:55:19', '2024-09-17 05:55:19', '2025-09-17 11:25:19'),
('3ee4b7adfa1763b564f4dab4d71fa6677a4a469c663f74deadc9a4d094f613773b957ad9378de422', 1, 1, NULL, '[]', 0, '2024-09-18 00:41:18', '2024-09-18 00:41:18', '2025-09-18 06:11:18'),
('3f3a5247a89ed0a2d9ce5983aa01333fb1e985881b91a51afef1645b801a9d2e4a73660c768b570e', 1, 1, NULL, '[]', 0, '2024-09-18 00:41:19', '2024-09-18 00:41:19', '2025-09-18 06:11:19'),
('3fde3e9c81739ff2a3c5273d02287467b546b3ef8541809fc414a25a33c5d6bc23ecc29afe5a5560', 1, 1, NULL, '[]', 0, '2024-09-18 00:45:32', '2024-09-18 00:45:32', '2025-09-18 06:15:32'),
('44c55ec5532f11d781c7c01e9dc14aaf119180884d676aec171efcf11e05058c2f207eb6ec743d4a', 1, 1, 'LiferunnerApp', '[]', 0, '2024-09-17 22:29:07', '2024-09-17 22:29:07', '2025-09-18 03:59:07'),
('4670e977d7a6adba81e9e0aac659b116917b4e277ecbf6095328aea12bf03f028191f6fa5de3737f', 1, 1, NULL, '[]', 0, '2024-09-18 00:48:31', '2024-09-18 00:48:31', '2025-09-18 06:18:31'),
('4b3c075601b4f8b2ab7422ee48d6322ccec333a9e6e7313949c8663b36f530504df909ccfac813ea', 21, 1, NULL, '[]', 0, '2024-09-17 05:54:51', '2024-09-17 05:54:51', '2025-09-17 11:24:51'),
('4b73621227734cc7f3b6553f41497e90e761026be65226a9f3542f05a49a80c09fd87bf5ea8cc511', 1, 1, NULL, '[]', 0, '2024-09-18 00:58:08', '2024-09-18 00:58:08', '2025-09-18 06:28:08'),
('4b89036a5e669716f8c8be1d6fc1e637f96ff7ba494f16e15be9cc6b483d1459ccd0248ce1bc615c', 1, 1, NULL, '[]', 0, '2024-09-18 02:25:04', '2024-09-18 02:25:04', '2025-09-18 07:55:04'),
('5a2b3f35f35c8e8fe978405b8b6644f8975bb777401ce1f26da155653a19f81b484b9de6f74a32ab', 1, 1, NULL, '[]', 0, '2024-09-18 02:34:12', '2024-09-18 02:34:12', '2025-09-18 08:04:12'),
('60cb83d3c82367770c3de7c9ecb2a541ccb1b42d7f6e998fe13eba25fda98467eedc722c2381e15c', 1, 1, NULL, '[]', 0, '2024-09-18 00:59:31', '2024-09-18 00:59:31', '2025-09-18 06:29:31'),
('61c20232fbd7e5f017fdfb77c7fed3965de52ba7e1107f3308b3fe2531fdac5e1c143b8a0ddea867', 1, 3, NULL, '[]', 0, '2024-09-18 04:40:54', '2024-09-18 04:40:54', '2025-09-18 10:10:54'),
('6e94390899490bad09a84bc087560481987d216dddfd861cca02a48e6f3cf4ecb02f41e7e863aa79', 1, 1, NULL, '[]', 0, '2024-09-18 00:51:08', '2024-09-18 00:51:08', '2025-09-18 06:21:08'),
('7915ec6f32006780e424943cdd09c47f1d8381962b82730848223b7878f0ad94596ff51ab06a5dbe', 1, 1, NULL, '[]', 0, '2024-09-18 03:35:24', '2024-09-18 03:35:24', '2025-09-18 09:05:24'),
('8498c6cbf9314a68998e7804c72195852a8ebc7b1c33f031318a88f4a2cd37600127e92ab86643bc', 1, 1, NULL, '[]', 0, '2024-09-18 01:33:49', '2024-09-18 01:33:49', '2025-09-18 07:03:49'),
('8f3694bd6b88b493ae3f67c651235d4c27cec1211aceae2239222340c0f7962689869ddc5e830bdb', 1, 1, NULL, '[]', 0, '2024-09-18 03:36:21', '2024-09-18 03:36:21', '2025-09-18 09:06:21'),
('8f3f4fc3e4e3102fae0ebacab33488605d6406edc483e01a83e7086c10c2e24171c2e4df26b75e53', 1, 1, NULL, '[]', 0, '2024-09-18 00:59:38', '2024-09-18 00:59:38', '2025-09-18 06:29:38'),
('a13eff68f2292bca8fdb2e2b568018551f881a234cf8e617c90ac0fc5dce8a58fa5af828904b3327', 1, 1, NULL, '[]', 0, '2024-09-18 00:59:46', '2024-09-18 00:59:46', '2025-09-18 06:29:46'),
('a4331aea33b139d98a35a0ccc84c56498e9105cb3362762adb13233451f4a68f40921715ad5deb53', 21, 1, NULL, '[]', 0, '2024-09-17 05:54:26', '2024-09-17 05:54:26', '2025-09-17 11:24:26'),
('a5c824c6ea6c9eb08cc00d353b6f805c8f86d5ef801664429774f2ecfae2afedceb0503a6b6303fb', 21, 1, 'LiferunnerApp', '[]', 0, '2024-09-17 05:58:50', '2024-09-17 05:58:50', '2025-09-17 11:28:50'),
('aab673facd8776dfdfca4ad8d8603e69158c620c8ac26ca5dc4799130692f6596516476d8f4f9cf1', 1, 1, NULL, '[]', 0, '2024-09-18 00:42:52', '2024-09-18 00:42:52', '2025-09-18 06:12:52'),
('ac4c291a38c6a45023d135b498fe30dbee23866e3ee3e7ebc1b8b559bc48bc4eea9cdd9ceb92ce30', 1, 1, NULL, '[]', 0, '2024-09-18 00:42:57', '2024-09-18 00:42:57', '2025-09-18 06:12:57'),
('af6d2413b3f7924437a876957af89f071a7609129cc5c0794ef49a84f75a1de756ea87574cdd8277', 1, 1, NULL, '[]', 0, '2024-09-18 01:34:47', '2024-09-18 01:34:47', '2025-09-18 07:04:47'),
('b12fbc90545ad83aeb1e11104b2fa52f43d36174bb2208d9e72586e2367b950ac5b3fb163f394f4d', 1, 1, NULL, '[]', 0, '2024-09-18 03:33:22', '2024-09-18 03:33:22', '2025-09-18 09:03:22'),
('b3912c5a0891b849164ce1ed9cf137de64e34c4d8fe15eac5ceecbf7cce1911f2c9ad6d593b2724f', 1, 1, NULL, '[]', 0, '2024-09-18 00:59:48', '2024-09-18 00:59:48', '2025-09-18 06:29:48'),
('bb4fa71042663b06084644c264a4697c0b078c077a164b503d251bc4171e8d84ae563af2e9ad8903', 21, 1, NULL, '[]', 0, '2024-09-17 05:51:29', '2024-09-17 05:51:29', '2025-09-17 11:21:29'),
('bb64706faf0b61a9d3a989a286c97987dcf8ddb6c38aef0f1c82e76664808133503c65f93fa85096', 1, 3, NULL, '[]', 0, '2024-09-18 03:46:40', '2024-09-18 03:46:40', '2025-09-18 09:16:40'),
('c355570c13ff5b6cb13dbb2fa8921be203e3439ce9817cab2288a9f9370922ad61efd162a84f35ab', 1, 3, NULL, '[]', 0, '2024-09-18 03:41:58', '2024-09-18 03:41:58', '2025-09-18 09:11:58'),
('c4e52a8f91b5430a2d1eb88b03d50e6c9bbbe5fb9963f12f30f61c2358b07151dd36802129b7cd2c', 1, 1, NULL, '[]', 0, '2024-09-18 00:46:25', '2024-09-18 00:46:25', '2025-09-18 06:16:25'),
('c8665662bd6938774c0a1fe61fa34b864fb073a3d6df30eb27e425471c3843bc87230ddf2c5ffbc8', 1, 1, NULL, '[]', 0, '2024-09-18 02:20:00', '2024-09-18 02:20:00', '2025-09-18 07:50:00'),
('c8d53f48f1fd966b320e31c4c61343075919c95912b284537545181bb6a40712f426236986013035', 1, 1, NULL, '[]', 0, '2024-09-18 02:38:25', '2024-09-18 02:38:25', '2025-09-18 08:08:25'),
('cc1c46bb750a9be8aab66d356a8fe45fa6c08818d156bcd003ce931222c5b0bdae49b1d06aaa5427', 1, 1, NULL, '[]', 0, '2024-09-18 03:35:22', '2024-09-18 03:35:22', '2025-09-18 09:05:22'),
('d5cfe81bca0ca51fa14aa195168aaa8f0fa05b30a27c5b737977978a7d001adbb3de32c4b0930281', 1, 1, NULL, '[]', 0, '2024-09-18 02:40:48', '2024-09-18 02:40:48', '2025-09-18 08:10:48'),
('d627e3b9cf35cde5761c80494823c84e8b984ffd87a955ae6ff92f9b59e1850fc76e7f18be297bc1', 21, 1, 'LiferunnerApp', '[]', 0, '2024-09-17 05:58:42', '2024-09-17 05:58:42', '2025-09-17 11:28:42'),
('e06b192ed3acd8a0251cf818f8523d22602c3c30867a08875f9796fe02fcfcfb563e2d96e7846469', 1, 1, NULL, '[]', 0, '2024-09-18 01:32:00', '2024-09-18 01:32:00', '2025-09-18 07:02:00'),
('e8f1124f751016238b19f702e74b9e1c4f2c4f50a126f3c67347a36d8f51a07c2fe8344115af2190', 1, 1, NULL, '[]', 0, '2024-09-18 02:20:04', '2024-09-18 02:20:04', '2025-09-18 07:50:04'),
('eb37948ac1e14d905a9b8bccd0cf1c1da866a5c94d4ae8ebd93d55864de741bc0237a86265145d63', 1, 3, NULL, '[]', 0, '2024-09-18 03:41:54', '2024-09-18 03:41:54', '2025-09-18 09:11:54'),
('eb83ce961d88d167cfdb672192bd188cc08370d9284fbdc405fb80db75af06de77235d9586c19452', 1, 1, NULL, '[]', 0, '2024-09-18 02:25:08', '2024-09-18 02:25:08', '2025-09-18 07:55:08'),
('ef30d4c74d5d6c3b577a3fa0e90210a984cfb50fe1218c03a29d36ceb9623a7b8cb617bf5ea0fe94', 1, 1, NULL, '[]', 0, '2024-09-18 00:43:35', '2024-09-18 00:43:35', '2025-09-18 06:13:35'),
('f630e86aeac4179679a43da74dfa1ed414ad28b314b02fd7ff151eede1d893cb24a5bea9a013096e', 1, 1, NULL, '[]', 0, '2024-09-18 02:21:15', '2024-09-18 02:21:15', '2025-09-18 07:51:15'),
('f740ace33d4b963672097880fd82cb8ab4eabd0c348c869e04ef1f2b7addc7aee372a1574bf60960', 1, 1, NULL, '[]', 0, '2024-09-18 02:40:31', '2024-09-18 02:40:31', '2025-09-18 08:10:31'),
('ff9cb21cecde3fac1671b019a2082de327ed8a49f2e9fd603d3d7b72d4ae0207620832acebe764df', 1, 1, NULL, '[]', 0, '2024-09-18 02:19:57', '2024-09-18 02:19:57', '2025-09-18 07:49:57');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
CREATE TABLE IF NOT EXISTS `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `client_id` int NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
CREATE TABLE IF NOT EXISTS `oauth_clients` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', '35wh5bb2gEBebzWvMAVpUvZbg0BkcoIBFfwZHqbw', 'http://localhost', 1, 0, 0, '2024-09-17 05:11:50', '2024-09-17 05:11:50'),
(2, NULL, 'Laravel Password Grant Client', 'fDF5VRqT3pUnSI1hyk4uSl2zENrRKGY1RrNmZtyc', 'http://localhost', 0, 1, 0, '2024-09-17 05:11:50', '2024-09-17 05:11:50'),
(3, NULL, 'Laravel Personal Access Client', 'Zpz6pswRwSSMWz2iZtxkw7OJbMOr1jLY2dydCqt9', 'http://localhost', 1, 0, 0, '2024-09-18 03:40:45', '2024-09-18 03:40:45'),
(4, NULL, 'Laravel Password Grant Client', 'O0lf4dGSdJpIKrMZ0Hv81DpjrKRlON8pN96nlyAG', 'http://localhost', 0, 1, 0, '2024-09-18 03:40:46', '2024-09-18 03:40:46');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
CREATE TABLE IF NOT EXISTS `oauth_personal_access_clients` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2024-09-17 05:11:50', '2024-09-17 05:11:50'),
(2, 3, '2024-09-18 03:40:46', '2024-09-18 03:40:46');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `participanttochapters`
--

DROP TABLE IF EXISTS `participanttochapters`;
CREATE TABLE IF NOT EXISTS `participanttochapters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chapter_id` int NOT NULL,
  `participant_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_participanttochapters_participant_id_1` (`participant_id`),
  KEY `fk_participanttochapters_chapter_id_1` (`chapter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21688 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `participanttochapters`
--

INSERT INTO `participanttochapters` (`id`, `chapter_id`, `participant_id`, `created_at`, `updated_at`) VALUES
(21685, 338, 24, '2024-09-16 22:32:19', '2024-09-17 11:17:47'),
(21686, 339, 19111, '2024-09-17 06:14:07', '2024-09-17 06:14:07'),
(21687, 340, 19112, '2024-09-17 22:31:11', '2024-09-17 22:31:11');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role`, `created_at`, `updated_at`) VALUES
(1, 'Admin', NULL, NULL),
(2, 'Chapter Leader', NULL, NULL),
(3, 'Participant', NULL, NULL),
(4, 'API Users', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int NOT NULL,
  `email` varchar(180) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_in_US` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `optin_accepted` tinyint(1) NOT NULL DEFAULT '0',
  `email_optin` tinyint(1) NOT NULL DEFAULT '1',
  `street_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zipcode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=19113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `title`, `first_name`, `last_name`, `role_id`, `email`, `password`, `birth_date`, `gender`, `live_in_US`, `phone`, `optin_accepted`, `email_optin`, `street_address`, `city`, `country`, `state`, `zipcode`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Admin', '', 1, 'admin@liferunners.org', '$2y$10$Zm54Yaz/.7HKPx/gS1Gv1uoaqIgJrElK/2G.pg4SPLGJD9BaFA4uW', '0000-00-00', '', NULL, '', 0, 1, NULL, NULL, NULL, NULL, NULL, 'q8wdABdfcI3G5EzKLehLHlYlcZL7fBU0nl0IVR7r94uCrMAbTJ1oIC5IIdlj', '2024-05-10 09:22:07', '2024-09-17 08:11:55'),
(21, NULL, 'Test', 'Hello', 3, 'apiuser@liferunners.org', '$2y$10$DefYHa2yM07tuB3UI5B0auG4l5EQZOKxyc8V9KR07UdzZa1sHJaQK', NULL, NULL, NULL, '1231231231', 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-10 09:22:07', '2024-09-17 06:03:58'),
(24, 'Mrs.', 'Meera', 'Mohan', 3, 'meeramohanmd@gmail.com', '$2y$10$AGHty525wMlCqiqrVmUVsuB6dxzMfQ7jNjWFOd1xXs35N2eSlxkPW', '2024-09-01', 'Female', 'Yes', '5014546446', 1, 1, NULL, NULL, 'US', 'IN', NULL, NULL, '2024-05-10 09:22:07', '2024-09-16 22:32:19'),
(19111, NULL, 'Test1', 'Hello', 3, 'sampleusesr@gmail.com', '$2y$10$NLcde.1aY.EVIR07IJl4X.kV10ayUCPgD4PFjmBypnU21f7CFcroK', NULL, NULL, NULL, '1231231236', 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, '2024-09-17 06:14:07', '2024-09-17 22:15:16'),
(19112, NULL, 'Tester', 'Hello1', 3, 'testusesr@gmail.com', '$2y$10$f4jpnwLEN.A6eNklmBh1HezISOdn0kXWgOM3Tg/wS3BG/dzw7ocZa', NULL, NULL, NULL, '1567878987', 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, '2024-09-17 22:31:11', '2024-09-17 22:31:11');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `participanttochapters`
--
ALTER TABLE `participanttochapters`
  ADD CONSTRAINT `fk_participanttochapters_chapter_id_1` FOREIGN KEY (`chapter_id`) REFERENCES `chapters` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_participanttochapters_participant_id_1` FOREIGN KEY (`participant_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
